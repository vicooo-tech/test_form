import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3 = new S3Client({
    region: "us-east-1"
});

export const handler = async () => {

    const key = `${Date.now()}.jpg`;

    const command = new PutObjectCommand({
        Bucket: "demo-060151519900-us-east-1-an",
        Key: key,
        ContentType: "image/jpeg"
    });

    const uploadUrl = await getSignedUrl(s3, command, {
        expiresIn: 300
    });

    return {
        statusCode: 200,
        body: JSON.stringify({
            uploadUrl,
            key
        })
    };
};