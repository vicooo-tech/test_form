import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const ses = new SESClient({
    region: "us-east-1"
});

const TO_EMAIL = "bruce.balfour@balgrist.ch";
const FROM_EMAIL = "bruce.balfour@balgrist.ch";

export const handler = async (event) => {

    try {

        for (const record of event.Records) {

            if (record.eventName !== "INSERT") {
                continue;
            }

            const item = record.dynamodb.NewImage;

            console.log("NEW ITEM:", JSON.stringify(item));

            // TODO:
            // Send item to OpenClaw API here
            const clawResponse = await fetch(
              "http://18.199.172.199:18789/tools/invoke",
              {
                  method: "POST",
                  headers: {
                      "Content-Type": "application/json",
                      "Authorization": "Bearer KCKaL4YAhaDQVbVCmWlZkaQjJcvaUAuL"
                  },
                  body: JSON.stringify({
                                tool: "chat",
                                input: {
                                    message: `
                    A new form submission arrived.
                    
                    ${JSON.stringify(item, null, 2)}
                    
                    Generate a professional summary email.
                    `
                                }
                            })
                        }
                    );
                    
            const clawData = await clawResponse.json();
                    
            console.log(clawData);

            const emailBody =     clawData.response ||
            JSON.stringify(clawData, null, 2);

            const command = new SendEmailCommand({
                Source: FROM_EMAIL,
                Destination: {
                    ToAddresses: [TO_EMAIL]
                },
                Message: {
                    Subject: {
                        Data: "New Form Submission"
                    },
                    Body: {
                        Text: {
                            Data: emailBody
                        }
                    }
                }
            });

            await ses.send(command);

            console.log("Email sent");
        }

    } catch (error) {

        console.error(error);

        throw error;
    }
};