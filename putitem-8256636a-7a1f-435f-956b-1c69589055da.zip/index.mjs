import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const REGION = "us-east-1";

const client = new DynamoDBClient({
    region: REGION
});

const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = "demo";

export const handler = async (event) => {

    try {

        console.log("EVENT:", JSON.stringify(event));

        const body =
            typeof event.body === "string"
                ? JSON.parse(event.body)
                : event.body;

        await docClient.send(
            new PutCommand({
                TableName: TABLE_NAME,
                Item: body
            })
        );

        return {
            statusCode: 200,
            body: JSON.stringify({
                success: true,
                item: body
            })
        };

    } catch (error) {

        console.error(error);

        return {
            statusCode: 500,
            body: JSON.stringify({
                error: error.message
            })
        };
    }
};